//
//  NotificationService.h
//  ImageNotification
//
//  Created by Filipe FALCO on 04/03/2022.
//

#import <UserNotifications/UserNotifications.h>

@interface NotificationService : UNNotificationServiceExtension

@end
